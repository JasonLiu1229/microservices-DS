# microservices-DS

Assignment 2, calendar service build on microservices.

There is also a [video](video.mp4) included in case something went wrong.

## Manual

1. Run the sh script [run.sh](run.sh).

## Report

[Report](./report/Microservices%20Distributed%20systems%202023-2024.pdf) is made with ieee paper format.
